#include <stdio.h>
#include <stdlib.h>
#include "Alumno.h"




int main()
{

    eAlumno miAlumno;

    miAlumno = cargarAlumno();
    mostrarUnAlumno(miAlumno);





    return 0;
}


