
int getInt(char[],int,int);
